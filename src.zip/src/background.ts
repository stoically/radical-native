import { Background } from "./background/lib";

new Background();
